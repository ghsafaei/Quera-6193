

## What is all this about?

This is a solution for problem
https://quera.org/problemset/6193/
using fortran.


## License




## Locally building the HTML for testing





## Getting started with 